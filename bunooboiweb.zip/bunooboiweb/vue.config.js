module.exports = {
    publicPath: '/',
    outputDir: 'dist/',
}
